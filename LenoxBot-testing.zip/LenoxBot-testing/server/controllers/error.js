function index(req, res) {
	res.render('error');
}

module.exports = {
	index: index
};
